﻿using UGameCore.Utilities;
using UnityEditor;

namespace SanAndreasUnity.Editor
{
    public class EditorWindowBase : EditorWindow
    {
    }
}
