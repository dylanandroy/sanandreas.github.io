﻿namespace SanAndreasUnity.Editor
{
    public class EditorCore
    {
        public const string MenuName = "San Andreas Unity";

        public const string PrefabsPath = "Assets/Prefabs";
    }
}
