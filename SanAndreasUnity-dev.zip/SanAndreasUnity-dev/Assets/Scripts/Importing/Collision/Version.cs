﻿namespace SanAndreasUnity.Importing.Collision
{
    public enum Version : byte
    {
        Unknown = 0,
        COLL = 1,
        COL2 = 2,
        COL3 = 3,
        COL4 = 4
    }
}